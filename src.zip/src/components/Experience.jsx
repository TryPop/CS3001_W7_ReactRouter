import React from 'react';

const Experience = () => {
  return (
    <div>
      <h1>Experience</h1>
      <ul>
        <li>Software Engineer at Company A, 2022-Present</li>
        <li>Intern at Company B, 2021</li>
      </ul>
    </div>
  );
};

export default Experience;
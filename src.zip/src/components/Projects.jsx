import React from 'react';

const Projects = () => {
  return (
    <div>
      <h1>Projects</h1>
      <ul>
        <li>Project 1: Description</li>
        <li>Project 2: Description</li>
      </ul>
    </div>
  );
};

export default Projects;
import React from 'react';

const Achievements = () => {
  return (
    <div>
      <h1>Achievements</h1>
      <ul>
        <li>Award 1</li>
        <li>Award 2</li>
      </ul>
    </div>
  );
};

export default Achievements;
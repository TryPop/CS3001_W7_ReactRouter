import React from 'react';

const Skills = () => {
  return (
    <div>
      <h1>Skills</h1>
      <ul>
        <li>JavaScript</li>
        <li>React</li>
        <li>Node.js</li>
        <li>Python</li>
      </ul>
    </div>
  );
};

export default Skills;
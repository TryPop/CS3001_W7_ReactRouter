import React from 'react';

const Education = () => {
  return (
    <div>
      <h1>Education</h1>
      <ul>
        <li>Bachelor's in Computer Science - University XYZ, 2020</li>
        <li>Master's in Software Engineering - University ABC, 2022</li>
      </ul>
    </div>
  );
};

export default Education;